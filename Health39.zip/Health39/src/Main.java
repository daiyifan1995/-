import org.jsoup.*;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import javax.naming.*;
import java.util.*;


import java.io.IOException;

import java.io.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static java.util.regex.Pattern.DOTALL;


public class Main {

    public static void main(String[] args)
    throws IOException {
        WuKKong h=new WuKKong();
        //h.downLoad("https://www.wukong.com/question/6640302414400323854/");
        Document doc=h.openHtml("6629573176592433415.html");
        h.parseHtml(doc);
        //h.writeresult(h.parseHtml(doc),"result.txt",false);
        //Document doc=h.openHtml("iRR0WTxGmmW7.html");
        //Map<String,Object>result=new HashMap<String,Object>();
        //result=h.getElement(doc);
        //h.writeresult(result,"output.txt",false);


    }

}
